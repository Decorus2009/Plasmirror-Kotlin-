package ui.controllers

import core.State
import core.util.Cmplx
import core.util.Medium
import core.util.Medium.OTHER
import core.util.Polarization
import core.util.Regime
import core.util.Regime.*
import javafx.fxml.FXML
import javafx.scene.control.ChoiceBox
import javafx.scene.control.Label
import javafx.scene.control.TextArea
import javafx.scene.control.TextField


// TODO validate parameters in external validator with alerts


class GlobalParametersController {

    lateinit var mainController: MainController

    @FXML lateinit var regimeController: RegimeController
    @FXML lateinit var temperatureController: TemperatureController
    @FXML lateinit var mediumParametersController: MediumParametersController
    @FXML lateinit var lightParametersController: LightParametersController

    @FXML
    fun initialize() {
        regimeController.globalParametersController = this
        temperatureController.globalParametersController = this
    }
}

class RegimeController {

    lateinit var globalParametersController: GlobalParametersController

    @FXML private lateinit var regimeChoiceBox: ChoiceBox<String>

    lateinit var regimeBefore: Regime

    @FXML
    fun initialize() {
        /* set initial value */
        regimeChoiceBox.selectionModel.selectFirst()

        regimeChoiceBox.selectionModel.selectedItemProperty().addListener { _, oldValue, newValue ->

            val newRegime = Regime.valueOf(newValue.toUpperCase())
            State.regime = newRegime
            regimeBefore = Regime.valueOf(oldValue.toUpperCase())

            with(globalParametersController) {
                if (newRegime === R || newRegime === T || newRegime === A) {
                    mediumParametersController.enableAll()
                    lightParametersController.enableAll()

                } else if (newRegime === EPS || newRegime === N) {
                    mediumParametersController.disableAll()
                    lightParametersController.disableAll()
                }
                // TODO
//                mainController.chartController.updateAxisesNames()
            }
        }
    }

    // TODO move writing parameters to State
//        fun writeRegime() =
//                writeToFile(path = "./data/inner/regime.txt", text = "${State.regime}")
}

class TemperatureController {

    lateinit var globalParametersController: GlobalParametersController

    @FXML private lateinit var T_TextField: TextField

    @FXML
    fun initialize() {
        /* set initial values */
        T_TextField.isDisable = true
    }
}

class MediumParametersController {

    @FXML private lateinit var leftMediumLabel: Label
    @FXML private lateinit var rightMediumLabel: Label
    @FXML private lateinit var n_leftMediumLabel: Label
    @FXML private lateinit var n_rightMediumLabel: Label
    @FXML private lateinit var n_leftRealTextField: TextField
    @FXML private lateinit var n_leftImaginaryTextField: TextField
    @FXML private lateinit var n_rightRealTextField: TextField
    @FXML private lateinit var n_rightImaginaryTextField: TextField
    @FXML private lateinit var leftMediumChoiceBox: ChoiceBox<String>
    @FXML private lateinit var rightMediumChoiceBox: ChoiceBox<String>

    @FXML
    fun initialize() {
        /* set initial values */
        leftMediumChoiceBox.selectionModel.select(0)
        rightMediumChoiceBox.selectionModel.select(1)

        n_leftRealTextField.isDisable = true
        n_leftImaginaryTextField.isDisable = true
        n_rightRealTextField.isDisable = true
        n_rightImaginaryTextField.isDisable = true


        leftMediumChoiceBox.selectionModel.selectedItemProperty().addListener { _, _, _ ->

            State.leftMedium = Medium.valueOf(leftMediumChoiceBox.value.toUpperCase())

            if (State.leftMedium == OTHER) {
                n_leftRealTextField.isDisable = false
                n_leftImaginaryTextField.isDisable = false
            } else {
                n_leftRealTextField.isDisable = true
                n_leftImaginaryTextField.isDisable = true
            }
        }

        rightMediumChoiceBox.selectionModel.selectedItemProperty().addListener { _, _, _ ->

            State.rightMedium = Medium.valueOf(rightMediumChoiceBox.value.toUpperCase())

            if (State.rightMedium == OTHER) {
                n_rightRealTextField.isDisable = false
                n_rightImaginaryTextField.isDisable = false
            } else {
                n_rightRealTextField.isDisable = true
                n_rightImaginaryTextField.isDisable = true
            }
        }

        n_leftRealTextField.textProperty().addListener { _, _, newValue ->
            try {
                State.n_left = with(n_leftImaginaryTextField) {
                    if (text.isEmpty()) Cmplx(newValue.toDouble())
                    else Cmplx(newValue.toDouble(), text.toDouble())
                }
            } catch (ignored: RuntimeException) {
            }
        }

        n_leftImaginaryTextField.textProperty().addListener { _, _, newValue ->
            try {
                State.n_left = with(n_leftRealTextField) {
                    if (text.isEmpty()) Cmplx(0.0, newValue.toDouble())
                    else Cmplx(newValue.toDouble(), text.toDouble())
                }
            } catch (ignored: RuntimeException) {
            }
        }

        n_rightRealTextField.textProperty().addListener { _, _, newValue ->
            try {

                State.n_right = with(n_rightImaginaryTextField) {
                    if (text.isEmpty()) Cmplx(newValue.toDouble())
                    else Cmplx(newValue.toDouble(), text.toDouble())
                }
            } catch (ignored: RuntimeException) {
            }
        }

        n_rightImaginaryTextField.textProperty().addListener { _, _, newValue ->
            try {
                State.n_right = with(n_rightRealTextField) {
                    if (text.isEmpty()) Cmplx(0.0, newValue.toDouble())
                    else Cmplx(newValue.toDouble(), text.toDouble())
                }
            } catch (ignored: RuntimeException) {
            }
        }
    }


// TODO move writing parameters to State
//
//    fun writeMediaParametersToFile() {
//
//        val output = StringBuilder()
//
//        output.append(State.leftMedium)
//        if (State.leftMedium == OTHER) {
//            output.append("\n${State.n_left.real} ${State.n_left.imaginary}\n")
//        }
//
//        output.append(State.rightMedium)
//        if (State.rightMedium == OTHER) {
//            output.append("\n${State.n_right.real} ${State.n_right.imaginary}\n")
//        }
//        writeToFile(path = "./data/inner/medium_parameters.txt", text = output.toString())
//    }

    fun disableAll() {

        leftMediumLabel.isDisable = true
        rightMediumLabel.isDisable = true
        n_leftMediumLabel.isDisable = true
        n_rightMediumLabel.isDisable = true

        leftMediumChoiceBox.isDisable = true
        rightMediumChoiceBox.isDisable = true

        n_leftRealTextField.isDisable = true
        n_leftImaginaryTextField.isDisable = true
        n_rightRealTextField.isDisable = true
        n_rightImaginaryTextField.isDisable = true
    }

    fun enableAll() {

        leftMediumLabel.isDisable = false
        rightMediumLabel.isDisable = false
        n_leftMediumLabel.isDisable = false
        n_rightMediumLabel.isDisable = false

        leftMediumChoiceBox.isDisable = false
        rightMediumChoiceBox.isDisable = false

        if (State.leftMedium == OTHER) {
            n_leftRealTextField.isDisable = false
            n_leftImaginaryTextField.isDisable = false
        }
        if (State.rightMedium == OTHER) {
            n_rightRealTextField.isDisable = false
            n_rightImaginaryTextField.isDisable = false
        }
    }
}

class CalculationRangeController {

    @FXML private lateinit var wLStartTextField: TextField
    @FXML private lateinit var wLEndTextField: TextField
    @FXML private lateinit var wLStepTextField: TextField

    @FXML
    fun initialize() {
        /* set initial values */
        wLStartTextField.text = State.wlStart.toString()
        wLEndTextField.text = State.wlEnd.toString()
        wLStepTextField.text = State.wlStep.toString()

        wLStartTextField.textProperty().addListener { _, _, newValue ->
            try {
                State.wlStart = newValue.toDouble()
            } catch (ignored: RuntimeException) {
            }
        }

        wLEndTextField.textProperty().addListener { _, _, newValue ->
            try {
                State.wlEnd = newValue.toDouble()
            } catch (ignored: RuntimeException) {
            }
        }

        wLStepTextField.textProperty().addListener { _, _, newValue ->
            try {
                State.wlStep = newValue.toDouble()
            } catch (ignored: RuntimeException) {
            }
        }
    }

// TODO move writing parameters to State
//        fun writeCalculationRange() =
//                writeToFile(path = "./data/inner/calculation_range.txt", text = "${State.wlStart}\n${State.wlEnd}${State.wlStep}")
}

class LightParametersController {

    @FXML private lateinit var angleLabel: Label
    @FXML private lateinit var polarizationLabel: Label
    @FXML private lateinit var polarizationChoiceBox: ChoiceBox<String>
    @FXML private lateinit var angleTextField: TextField

    @FXML
    fun initialize() {
        /* set initial values */
        polarizationChoiceBox.value = State.polarization.toString()
        angleTextField.text = State.angle.toString()

        polarizationChoiceBox.selectionModel.selectedItemProperty()
                .addListener { _, _, _ -> State.polarization = Polarization.valueOf(polarizationChoiceBox.value) }

        angleTextField.textProperty()
                .addListener { _, _, newValue ->
                    try {
                        State.angle = newValue.toDouble()
                    } catch (ignored: RuntimeException) {
                    }
                }
    }

    fun disableAll() {

        polarizationLabel.isDisable = true
        polarizationChoiceBox.isDisable = true
        angleLabel.isDisable = true
        angleTextField.isDisable = true
    }

    fun enableAll() {

        polarizationLabel.isDisable = false
        polarizationChoiceBox.isDisable = false
        angleLabel.isDisable = false
        angleTextField.isDisable = false
    }

// TODO move writing parameters to State
//    fun writeLightParameters() =
//            writeToFile(path = "./data/inner/light_parameters.txt", text = "${State.polarization}\n${State.angle}")
}

class StructureDescriptionController {

    @FXML private lateinit var structureDescriptionTextArea: TextArea

    @FXML
    fun initialize() {
        /* set initial values */
        structureDescriptionTextArea.text = State.structureDescriptionStringRepresentation

        structureDescriptionTextArea.textProperty().addListener { _, _, newValue ->
            State.structureDescriptionStringRepresentation = newValue
        }
    }

    // TODO move writing parameters to State
//        fun writeStructureDescription() =
//                writeToFile(path = "./data/inner/regime.txt", text = "${State.regime}")
}

