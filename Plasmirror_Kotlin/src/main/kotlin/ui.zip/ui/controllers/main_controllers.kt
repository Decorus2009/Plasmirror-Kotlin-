package ui.controllers

import MainApp
import javafx.application.Platform
import javafx.fxml.FXML

class RootController {

    //    @FXML lateinit var menuController: MenuController
    @FXML lateinit var mainController: MainController

    lateinit var mainApp: MainApp

    @FXML
    fun initialize() {
//        menuLayoutController.setRootController(this)

        /*
        mainController is "lateinit" due to it's initialized through the reflection (@FXML)
        BEFORE the root controller initialization.
         */
        mainController.rootController = this
    }
}


class MainController {

    lateinit var rootController: RootController
    private lateinit var mainApp: MainApp
    @FXML lateinit var structureDescriptionController: StructureDescriptionController
    @FXML lateinit var globalParametersController: GlobalParametersController
//    @FXML val chartController: ChartController
//    @FXML val controlsController: ControlsController
//    @FXML private val xAxisRangeController: XAxisRangeController
//    @FXML private val yAxisRangeController: YAxisRangeController
//    @FXML val graphManagerController: GraphManagerController
//    @FXML private val calculationTimeLabel: Label

//    fun setRootController(rootController: RootController) {
//        this.rootController = rootController
//    }


    // TODO подумать, как, не нажимая кнопку calculationButton, запустить расчет при изменени value в choiceBox для поляризации
    // это можно сделать через listener, как в GraphManagerController
    @FXML
    fun initialize() {

        globalParametersController.mainController = this

//        controlsController.setMainController(this)
//        chartController.setMainController(this)
//        graphManagerController.setMainController(this)
//        xAxisRangeController.setMainController(this)
//        yAxisRangeController.setMainController(this)
//        globalParametersController.setMainController(this)
    }

//    fun writeChangingsToFiles() {
//
//        globalParametersController.writeGlobalParamsToFiles()
//        structureDescriptionController.writeStructureDescriptionToFile()
//    }
}
