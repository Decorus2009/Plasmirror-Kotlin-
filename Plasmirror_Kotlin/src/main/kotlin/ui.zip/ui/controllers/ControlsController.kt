package ui.controllers

import core.util.StructureDescriptionException
import javafx.application.Platform
import javafx.fxml.FXML
import javafx.scene.control.Alert
import javafx.scene.control.Button
import javafx.scene.control.Label
import javafx.scene.input.KeyCode
import javafx.scene.input.KeyCodeCombination
import javafx.scene.input.KeyCombination
import java.util.*


class ControlsController {

    private lateinit var mainLayoutController: MainController
    @FXML private lateinit var calculationTimeLabel: Label
    @FXML private lateinit var computeButton: Button

    @FXML
    fun initialize() {
        Platform.runLater { computeButton.scene.accelerators
                .put(KeyCodeCombination(KeyCode.SPACE, KeyCombination.SHORTCUT_DOWN), Runnable { computeButton.fire() }) }

        computeButton.setOnAction {

//            validateStateParameters()
//            compute()

            println("Compute") }
        /* NPE without Platform.runLater */



    }

    /**
     * При нажатии происходит обновление параметров структуры и глобальных параметров.
     * В текстовых полях (например, угол) надо после их модификации нажимать Enter.
     * Это происходит не всегда, поэтому апдейт вызывается еще раз непосредственно с щелчком мыши.
     * После апдейтов (когда проставляются необходимые глобальные параметры и описание структуры)
     * вызывается метод recreateMirror(), в котором пересоздается объект Mirror
     * (в котором как раз глобальные параметры используются).
     *
     *
     * При каждом клике мыши (а не при закрытии (что более логично)) все изменения,
     * вводимые в окне программы, записываются в файл
     * на быстродействие это не влияет
     */
//    @FXML
//    fun computeButtonClicked() {
//
//        try {
//            mainLayoutController.structureDescriptionController.updateStructureDescription()
//        } catch (e: StructureDescriptionException) {
//            showStructureDescriptionsAlert(e.getMessage())
//        }
//
//        mainLayoutController.chartController.updateIfAnotherRegime()
//
//        initAndCalculate()
//    }
//
//
//    private fun initAndCalculate() {
//
//        val calculationTime: Double
//        var startTime: Long
//        var stopTime: Long
//
//        State.buildMirror()
//
//        startTime = System.nanoTime()
//        State.calculate()
//        stopTime = System.nanoTime()
//        calculationTime = (stopTime - startTime).toDouble()
//
//        startTime = System.nanoTime()
//        mainLayoutController.getChartController().updateCalculationSeries()
//        stopTime = System.nanoTime()
//
//        mainLayoutController
//                .getControlsController()
//                .setCalcTimeLabelText(
//                        "Calculation time: "
//                                + String.format(Locale.US, "%.2f", calculationTime / 1E6)
//                                + " (ms). Line chart initCalculated time: "
//                                + String.format(Locale.US, "%.2f", (stopTime - startTime).toDouble() / 1E6)
//                                + " (ms)"
//                )
//    }
//
//    private fun initCalcButtonAccelerator() =
//            computeButton.scene.accelerators
//                    .put(KeyCodeCombination(KeyCode.SPACE, KeyCombination.SHORTCUT_DOWN), Runnable { computeButton.fire() })
//
//
//    private fun showStructureDescriptionsAlert(message: String) {
//
//        val alert = Alert(Alert.AlertType.ERROR)
//        alert.title = "Error"
//        alert.headerText = "Structure description error"
//        alert.contentText = message
//
//        alert.showAndWait()
//    }
//
//    fun setMainLayoutController(mainLayoutController: MainLayoutController) {
//        this.mainLayoutController = mainLayoutController
//    }
//
//    fun setCalcTimeLabelText(text: String) {
//        calculationTimeLabel.text = text
//    }
}
